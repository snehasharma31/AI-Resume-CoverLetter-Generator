function analyzeATS(resumeText, jobDescription = "") {


    const resume = resumeText.toLowerCase();

    const job = jobDescription.toLowerCase();



    const keywords = [

        "javascript",
        "node.js",
        "express",
        "mongodb",
        "sql",
        "react",
        "python",
        "java",
        "html",
        "css",
        "git",
        "api",
        "rest",
        "database",
        "project",
        "internship",
        "communication",
        "problem solving"

    ];



    let matchedKeywords = [];

    let missingKeywords = [];



    keywords.forEach(keyword => {


        if (resume.includes(keyword)) {

            matchedKeywords.push(keyword);

        }
        else if (job.includes(keyword)) {

            missingKeywords.push(keyword);

        }

    });



    let score = 40;


    score += matchedKeywords.length * 3;



    if (resume.length > 1000) {

        score += 10;

    }



    if (score > 95) {

        score = 95;

    }



    let strengths = [];

    let weaknesses = [];

    let suggestions = [];



    if (matchedKeywords.length >= 5) {

        strengths.push(
            "Good technical skills coverage"
        );

    }


    if (resume.includes("project")) {

        strengths.push(
            "Projects are mentioned"
        );

    }



    if (!resume.includes("achievement")) {

        weaknesses.push(
            "Add measurable achievements"
        );

    }


    if (!resume.includes("summary")) {

        weaknesses.push(
            "Improve professional summary"
        );

    }



    suggestions.push(
        "Add job specific keywords"
    );


    suggestions.push(
        "Mention measurable project results"
    );


    suggestions.push(
        "Keep resume ATS friendly"
    );



    return {

        score,

        strengths,

        weaknesses,

        missingKeywords,

        suggestions

    };

}



module.exports = {
    analyzeATS
};