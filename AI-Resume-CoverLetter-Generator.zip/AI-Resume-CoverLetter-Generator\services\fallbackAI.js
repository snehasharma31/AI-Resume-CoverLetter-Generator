const {
    analyzeATS
} = require("./atsAnalyzer");



function fallbackResumeAnalysis(
    resumeText,
    jobDescription
){


    const analysis =
        analyzeATS(
            resumeText,
            jobDescription
        );



    return {


        atsScore:
            analysis.score,


        strengths:
            analysis.strengths,


        weaknesses:
            analysis.weaknesses,


        missingKeywords:
            analysis.missingKeywords,


        suggestions:
            analysis.suggestions,


        message:
            "AI service unavailable. Using intelligent fallback analysis."

    };


}



function generateFallbackCoverLetter(data){


    return `

Dear Hiring Manager,


I am excited to apply for the ${data.role} position at ${data.company}.


I have skills in ${data.skills} and I am continuously improving my technical abilities through projects and practical learning.


${data.details || ""}


I believe my skills and dedication make me a suitable candidate for this opportunity.


Thank you for considering my application.


Regards,

${data.name}

`;

}



module.exports = {

    fallbackResumeAnalysis,

    generateFallbackCoverLetter

};