const express = require("express");

const router = express.Router();

const multer = require("multer");
const path = require("path");

const {
    analyzeResume
} = require("../controllers/resumeController");



// ===============================
// Multer Storage
// ===============================

const storage = multer.diskStorage({

    destination: function(req, file, cb){

        cb(
            null,
            "uploads/"
        );

    },


    filename: function(req, file, cb){

        cb(
            null,
            Date.now() + "-" + file.originalname
        );

    }

});




// ===============================
// File Filter
// ===============================

const fileFilter = (req, file, cb)=>{


    if(
        file.mimetype === "application/pdf"
    ){

        cb(null, true);

    }
    else{

        cb(
            new Error("Only PDF files are allowed"),
            false
        );

    }

};




// ===============================
// Upload Middleware
// ===============================

const upload = multer({

    storage: storage,

    fileFilter: fileFilter,

    limits: {

        fileSize: 5 * 1024 * 1024

    }

});




// ===============================
// Resume Analyze Route
// URL:
// POST /resume/analyze
// ===============================

router.post(

    "/analyze",

    upload.single("resume"),

    analyzeResume

);





module.exports = router;