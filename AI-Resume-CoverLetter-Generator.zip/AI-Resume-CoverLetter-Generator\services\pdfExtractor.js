const fs = require("fs");
const pdf = require("pdf-parse");


async function extractText(filePath){

    try{

        const buffer = fs.readFileSync(filePath);

        const data = await pdf(buffer);


        return data.text;


    }
    catch(error){

        console.error(
            "PDF Extraction Error:",
            error.message
        );


        throw new Error(
            "Unable to extract resume text"
        );

    }

}



module.exports = {
    extractText
};