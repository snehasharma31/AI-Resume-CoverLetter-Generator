const path = require("path");

const {
    extractText
} = require("../services/pdfExtractor");


const {
    analyzeResume: geminiAnalyzeResume
} = require("../services/geminiService");


const {
    fallbackResumeAnalysis
} = require("../services/fallbackAI");



async function analyzeResume(req, res) {

    try {


        if (!req.file) {

            return res.status(400).render(
                "error",
                {
                    title: "Upload Error",
                    error: "Please upload a PDF resume file."
                }
            );

        }



        const filePath = path.join(
            __dirname,
            "..",
            req.file.path
        );



        const resumeText = await extractText(filePath);



        const jobDescription =
            req.body.jobDescription || "";



        let analysis;



        try {


            if (process.env.GEMINI_API_KEY) {


                const aiResponse =
                    await geminiAnalyzeResume(
                        resumeText,
                        jobDescription
                    );


                analysis = {

                    atsScore: "AI Generated",

                    strengths: [
                        aiResponse
                    ],

                    weaknesses: [
                        "Review AI suggestions carefully"
                    ],

                    missingKeywords: [],

                    suggestions: [
                        "Improve resume according to job description"
                    ],

                    message:
                    "Analysis generated using Gemini AI"

                };


            }
            else {


                analysis =
                    fallbackResumeAnalysis(
                        resumeText,
                        jobDescription
                    );


            }



        }
        catch(error) {


            console.log(
                "Gemini failed. Using fallback analysis."
            );


            analysis =
                fallbackResumeAnalysis(
                    resumeText,
                    jobDescription
                );


        }



        return res.render(
            "result",
            {

                title:
                "Resume Analysis Result",

                analysis,

                resumeText

            }
        );



    }
    catch(error) {


        console.error(
            "Resume Controller Error:",
            error
        );


        return res.status(500).render(
            "error",
            {

                title:
                "Server Error",

                error:
                error.message

            }
        );


    }

}



module.exports = {

    analyzeResume

};