const path = require("path");

const {
    generateFallbackCoverLetter
} = require("../services/fallbackAI");


const {
    generatePDF
} = require("../utils/pdfGenerator");


// Temporary storage
let coverLetterData = {};

let generatedLetter = "";



// Generate Cover Letter

async function generateCoverLetter(req, res) {

    try {


        const data = {


            name: req.body.name,

            role: req.body.role,

            company: req.body.company,

            skills: req.body.skills,

            details: req.body.details || ""


        };



        coverLetterData = data;



        generatedLetter =
            generateFallbackCoverLetter(data);



        res.render(
            "cover-result",
            {

                title:
                "Generated Cover Letter",


                ...data,


                letter:
                generatedLetter

            }
        );



    }
    catch(error){


        console.error(error);



        res.status(500).render(
            "error",
            {

                title:
                "Server Error",


                error:
                error.message

            }
        );


    }

}




// Download PDF

function downloadCoverLetter(req,res){


    try{


        const filePath =
            path.join(
                __dirname,
                "..",
                "uploads",
                "cover-letter.pdf"
            );



        generatePDF(
            coverLetterData,
            filePath
        );



        res.download(
            filePath,
            "AI-Cover-Letter.pdf"
        );



    }
    catch(error){


        console.error(error);


        res.status(500).send(
            "PDF generation failed"
        );


    }


}




module.exports = {

    generateCoverLetter,

    downloadCoverLetter

};