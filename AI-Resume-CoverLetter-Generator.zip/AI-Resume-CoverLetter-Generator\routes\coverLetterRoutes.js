const express = require("express");

const router = express.Router();

const {
    generateCoverLetter,
    downloadCoverLetter
} = require("../controllers/coverLetterController");



// Show Cover Letter Page

router.get("/", (req,res)=>{

    res.render(
        "cover-letter",
        {
            title:"AI Cover Letter Generator"
        }
    );

});



// Generate Cover Letter

router.post(
    "/",
    generateCoverLetter
);



// Download PDF

router.get(
    "/download",
    downloadCoverLetter
);



module.exports = router;