const { GoogleGenAI } = require("@google/genai");

const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY
});

async function analyzeResume(resumeText, jobDescription) {

    const prompt = `
You are an ATS Resume Analyzer.

Resume:
${resumeText}

Job Description:
${jobDescription}

Analyze the resume and provide:
1. ATS Score
2. Strengths
3. Weaknesses
4. Missing Keywords
5. Suggestions
`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-pro",
        contents: prompt
    });

    return response.text;
}

module.exports = { analyzeResume };